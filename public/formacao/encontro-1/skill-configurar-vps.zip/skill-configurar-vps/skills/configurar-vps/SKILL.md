---
name: configurar-vps
description: Leva o aluno da "não tenho servidor" até o Hermes rodando sozinho numa VPS blindada, chamando na ordem certa as skills escolher-vps, diagnosticar-vps, blindar-vps, instalar-hermes-vps e acesso-privado, com um teste entre cada etapa. Use quando o aluno disser "configure minha VPS", "monta o meu servidor", "quero meu agente rodando 24 horas" ou "faça tudo da VPS".
---

# Configurar a VPS de ponta a ponta

Esta é a porta de entrada. Ela não repete o passo a passo das outras skills: **decide a ordem, confere o resultado de cada etapa e só então libera a próxima.** O trabalho de cada etapa está na skill dela, na pasta ao lado desta.

Quem clica em comprar, digita senha de conta ou faz login em painel é sempre o aluno. Você nunca compra, nunca pede nem guarda senha, e a chave SSH privada nunca sai do computador dele.

## O mapa

| # | Etapa | Skill | Quando entra | Pronto quando |
|---|---|---|---|---|
| 0 | Onde estamos | (perguntas abaixo) | sempre | você sabe em qual caso o aluno está |
| 1 | Escolher o plano | `escolher-vps` | só se ele ainda não tem VPS | o aluno comprou e te deu IP e chave |
| 2 | Olhar o que já existe | `diagnosticar-vps` | só se a VPS já roda coisas | você tem o relatório e ele concordou com o que fica de fora |
| 3 | Blindar | `blindar-vps` | sempre | os 4 serviços `active` e só a porta 22 responde de fora |
| 4 | Instalar o Hermes | `instalar-hermes-vps` | sempre | `systemctl is-active hermes` = `active` e backup de poucos MB |
| 5 | Ver o painel em privado | `acesso-privado` | se o aluno quiser o painel | `nc -vz IP 9119` de fora **falha** e o túnel abre |
| 6 | Conectar e provar | (esta skill) | sempre | primeira resposta chegou no celular, e a VPS voltou sozinha após reiniciar |

## Etapa 0: descubra o caso (pergunte só o que falta)
1. **Já tem uma VPS?** Não → começa na etapa 1. Sim → siga.
2. **Ela já roda outras coisas** (site, banco, painel, Docker)? Sim → etapa 2 é obrigatória e a 3 só avança nos itens que ela liberar. Não, é nova → pule a 2.
3. **IP da VPS, caminho da chave SSH privada e o nome do usuário que ele quer** (padrão `admin`). Se ele só tem a senha do root e não tem chave, **pare**: ajude-o a cadastrar a chave no painel do provedor primeiro. A skill `blindar-vps` tranca a senha, e sem chave ele fica de fora.
4. **Ele vai querer ver o painel do Hermes?** Define se a etapa 5 entra.

Diga a ele, em três linhas, qual é o caminho que vocês dois vão fazer. Ex.: "Servidor novo: escolher, blindar, instalar e provar. Umas duas horas, e eu paro e mostro a tela em cada teste."

## Regras que valem em todas as etapas
- **Um teste entre cada etapa, e você mostra a saída.** Se o teste falhar, **pare**, mostre a saída ao aluno e só continue depois de resolver. Nunca "tente o passo seguinte para ver".
- **Duas janelas.** Antes da etapa 3, peça ao aluno uma segunda sessão SSH aberta e parada. Ela é o plano B se o acesso quebrar.
- **Uma etapa por vez, e uma frase didática depois de cada uma** (o que ela protege, em português simples; sigla com o significado na primeira vez). As frases-base estão na `blindar-vps`.
- **Segredo que apareceu num log é segredo comprometido.** Avise o aluno para trocá-lo.
- **Só trabalhe em servidor que é do aluno.** Pergunte uma vez, de forma direta.
- **Nunca invente comando, flag ou endereço de instalação.** Onde a skill diz "copiado no dia", é de propósito: abra a página oficial, leia e copie. Endereço de memória falha depois de já ter mexido na máquina.

## Etapas 1 a 5
Execute a skill da linha do mapa, do começo ao fim, e só volte aqui quando a coluna "Pronto quando" estiver verdadeira **e visível na tela**. Entre as etapas, diga ao aluno onde vocês estão: "Etapa 3 de 6 concluída: o servidor está blindado. Próxima: instalar o Hermes."

## Etapa 6: conectar e provar (só esta skill faz)
O instalador deixa o serviço de pé, **mas não liga o Telegram nem o modelo.** Isso exige a conta e a assinatura do aluno, então é ele quem decide e autentica; você guia.

1. Com o aluno, conecte o canal (Telegram) e o modelo ao Hermes **na VPS**, como na Hermes Week (Aulas 1 e 2), se ele fez; se não fez, guie do zero pelo que a versão instalada mostrar. Siga o que a versão instalada mostrar (`hermes --help`); não invente comando.
2. **Primeira resposta vinda de fora:** o aluno manda uma mensagem do celular e o agente responde. Sem isso a VPS não está pronta.
3. **O teste das três da manhã:** reinicie a VPS (`sudo reboot`), espere um minuto e confira `systemctl is-active hermes`. Tem que voltar sozinho. Depois mande outra mensagem do celular e veja a resposta.
4. Confirme o backup: `ls -lh /var/backups/hermes` mostra pelo menos um arquivo de poucos MB.
5. Se o vigia do Telegram foi ligado, derrube o serviço de propósito (`sudo systemctl stop hermes`) e espere até 3 minutos: o vigia confere de 2 em 2 minutos e só avisa quando o estado muda. Quando o aviso chegar, suba de novo (`sudo systemctl start hermes`) e espere o aviso de volta. Vigia que nunca foi testado não conta como vigia.

## Entregue no fim (uma tabela, sem enfeite)
| Item | Estado |
|---|---|
| Usuário comum com sudo, root bloqueado | ✅ ou ❌ |
| SSH só com chave, senha desligada | |
| Firewall: só a porta 22 aberta **vista de fora** | |
| fail2ban e atualizações automáticas ativos | |
| Hermes como serviço, volta sozinho depois de reiniciar | |
| Backup diário (último arquivo e tamanho) | |
| Painel só local; acesso por túnel ou Tailscale | |
| Primeira resposta chegou no celular | |

Termine com o que ficou **sem teste** (ver abaixo) e com o próximo passo do aluno.

## O que ainda não foi testado (diga ao aluno se ele perguntar, e sempre no resumo final)
- O `instalar-hermes.sh` corrigido (20/10/2026) **ainda não rodou numa VPS nova de ponta a ponta.** Os seis erros que ele trata vieram de um teste real de 29/09 numa Hostinger com Ubuntu 24.04; a versão corrigida passou só por checagem de sintaxe e por teste do backup isolado.
- A `blindar-vps` foi executada de verdade em 29/09/2026 (Hostinger, Ubuntu 24.04). A `diagnosticar-vps` foi testada só de leitura numa VPS Debian 12 com Docker Swarm.
- O caminho Tailscale da `acesso-privado` não foi testado. O túnel SSH foi.
- O campo de script pós-instalação do painel da Hostinger não foi testado.
Se algo disso falhar na máquina do aluno, **não improvise**: pare, guarde o log (`/var/log/instalar-hermes.log`) e peça ao aluno para mandar no grupo.

## Quando o aluno trava
| Sintoma | Vá para |
|---|---|
| Não entra mais por SSH depois da etapa 3 | Segunda janela: restaure `/etc/ssh/sshd_config.bak-hardening`. Se fechou, console web do painel do provedor |
| Ferramenta que entrava como root parou (Coolify e similares) | `blindar-vps`, armadilha "ferramentas que entram como root" |
| Porta aberta de fora que o firewall diz estar fechada | É o Docker. `blindar-vps`, armadilha do Docker |
| Instalador parou no meio | `/var/log/instalar-hermes.log`; o fim do log mostra a causa |
| Serviço sobe e cai depois de minutos | Quase sempre memória: `free -h`, ou plano maior, ou modelo mais leve |
| Voltou sozinho, mas esqueceu tudo | Pasta de configuração em lugar errado; restaurar o último backup |

Estado: criada em 26/10/2026 sobre as cinco skills de VPS já entregues no Encontro 1. Ela só orquestra, e não traz comando novo de servidor.
