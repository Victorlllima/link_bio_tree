# Skill de configuração da VPS · Encontro 1

Uma skill de entrada, `configurar-vps`, que conduz o seu agente (Claude Code, Codex ou Hermes) do servidor vazio
até o Hermes rodando sozinho, blindado e com backup. As outras cinco são as etapas que ela chama.

## Instalar (uma vez)

Copie **todas** as pastas de `skills/` para a pasta de skills do seu agente (Claude Code: `~/.claude/skills/`).
Copie também o `instalar-hermes.sh` para a pasta de onde você vai conversar com o agente: a skill pede esse arquivo.

## Usar

Abra o agente e diga: **"configure a minha VPS"**. Ele pergunta o que falta e segue a ordem abaixo, parando em
cada teste. Você só faz o que é seu: comprar o plano, cadastrar a chave SSH e entrar nas suas contas.

## A ordem (a mesma que a skill segue)

1. `escolher-vps`: só se você ainda não tem servidor.
2. `diagnosticar-vps`: só se a VPS já roda outras coisas. Só lê, não muda nada.
3. `blindar-vps`: usuário comum, SSH só com chave, firewall, fail2ban, senha do root trancada.
4. `instalar-hermes-vps`: o Hermes como serviço que volta sozinho, com backup e vigia.
5. `acesso-privado`: ver o painel sem abrir porta. Opcional.
6. Conectar o Telegram e o modelo, testar de fora e reiniciar a máquina para provar que volta sozinho.

**Blindar vem antes de instalar.** Se algum material seu mostrar a ordem ao contrário, vale esta.

## Avisos honestos

- O `instalar-hermes.sh` corrigido ainda não rodou de ponta a ponta numa VPS nova. Os erros que ele trata vieram de
  um teste real de 29/09 (Hostinger, Ubuntu 24.04). Se parar, o log fica em `/var/log/instalar-hermes.log`: mande no grupo.
- A blindagem foi executada de verdade em 29/09. O diagnóstico foi testado só de leitura.
- O caminho Tailscale do acesso privado não foi testado. O túnel SSH foi.
- A chave SSH privada fica só no seu computador. Não cole em chat, nem para o agente.

`checklist-de-blindagem-da-vps.pdf` é o mesmo passo a passo em papel, para você conferir o que o agente fez.
