# O squad pronto para importar

Cinco agentes montados, com a função de cada um já escrita, o modelo certo apontado em cada um e o
quadro de tarefas configurado.

Você importa, e vê um time se mexendo na primeira noite. Entender como cada peça funciona vem
depois.

---

## O time

| Agente | O que ele faz | Que modelo vai nele |
|---|---|---|
| **Coordenador** | Recebe a demanda, quebra em tarefas, escolhe quem faz e acompanha. **Nunca executa** | O seu mais capaz |
| **Pesquisador** | Acha informação e confere. Traz a fonte e a data junto | Um intermediário, de janela grande |
| **Redator** | Escreve. Só começa com material na mão | O seu mais capaz |
| **Revisor** | Última peneira. Confere fato, coerência e as regras. Aprova ou devolve | O seu mais capaz |
| **Operador** | O trabalho mecânico: organizar, renomear, extrair, tabular, converter | **O mais barato que você tiver** |

**Por que o operador leva o modelo barato.** Ele não decide nada. Ele executa o que já foi decidido,
e executa muito, várias vezes por dia. É onde a conta cresce sem você perceber, e é onde um modelo
caro não te dá nada em troca.

**Por que são cinco e não dez.** Agente demais dividindo a mesma demanda vira bagunça, e você
descobre isso tarde. Cinco funções cobrem quase tudo que uma pessoa sozinha faz num dia. Quando você
sentir falta de um sexto, você vai saber exatamente qual é.

---

## Como instalar, do jeito mais fácil

Abre o Hermes Desktop, começa uma sessão nova e manda isto, com esta pasta aberta na sua frente:

```
Eu tenho uma pasta chamada squad-pronto, em [COLE AQUI O CAMINHO DA PASTA].

Dentro dela tem uma pasta perfis, com cinco pastas: coordenador, pesquisador, redator, revisor e
operador. Cada uma tem um SOUL.md, um profile.yaml e um config.yaml.

Eu quero que você:

1. Crie esses cinco perfis no meu Hermes, copiando o SOUL.md e o profile.yaml de cada um.
2. No config.yaml de cada um, os valores estão escritos como TROQUE-PELO-SEU-MODELO e
   TROQUE-PELO-SEU-PROVIDER. Me mostre a lista dos modelos e providers que EU tenho disponíveis
   hoje, e me pergunte qual eu quero em cada um dos três níveis: o capaz, o intermediário e o mais
   barato. Só depois da minha resposta você escreve os arquivos.
3. Escolha também um modelo gratuito de fallback para todos, e me diga qual escolheu e por quê.
4. Depois de criar tudo, reinicie o gateway e me confirme que os cinco perfis apareceram, dizendo
   onde eu vejo cada um na tela.
5. Por último, me mostre o nome exato de cada perfil, para eu saber como chamar cada um.

Não invente nome de modelo. Se você não tiver certeza de que um modelo existe na minha instalação,
me pergunte.
```

⚠️ **O passo 2 é o que salva a sua conta.** Não deixe ele chutar nome de modelo, porque os nomes
mudam e um nome errado faz o agente falhar em silêncio.

---

## Como instalar na mão

Se você preferir fazer você mesmo, a estrutura é essa. Cada perfil do Hermes é uma pasta dentro de
`profiles`, dentro da pasta de configuração do Hermes, com três arquivos:

- **`SOUL.md`** — quem ele é e o que ele nunca faz. É o arquivo da Aula 2.
- **`profile.yaml`** — o nome que aparece na tela e a descrição.
- **`config.yaml`** — o modelo, o provider e o fallback.

Copia as cinco pastas de `perfis/` para lá, troca os três `TROQUE-...` de cada `config.yaml` pelo que
você usa, e reinicia o gateway.

⚠️ Se você não souber onde fica a sua pasta de configuração, não saia procurando. Pergunta:

```
Onde fica a pasta de configuração do meu Hermes nesta máquina, e onde ficam os perfis dentro dela?
```

---

## Depois de instalar: o quadro

O squad sem quadro é só um monte de agente. O quadro é onde a coisa acontece sozinha.

Instala um plugin de Kanban pelo catálogo (**Capabilities › Plugins**), e depois manda:

```
Configure o quadro de tarefas para funcionar com o meu squad. Quero quatro colunas: a fazer,
fazendo, esperando mim e feito.

Regras:
- Toda tarefa nova entra em "a fazer" e vai para o coordenador.
- O coordenador quebra em subtarefas e designa cada uma ao agente certo, pelo que está escrito no
  SOUL.md de cada um.
- Quando um agente começa, o card vai para "fazendo" sozinho.
- Quando uma tarefa precisa de uma decisão minha ou de uma aprovação, o card vai para "esperando
  mim" e eu recebo um aviso no Telegram dizendo o que você precisa de mim.
- Quando termina, vai para "feito".

Me confirme que configurou, e me mostre o quadro vazio.
```

---

## O primeiro teste, para ver funcionando hoje

Joga uma tarefa grande de verdade no quadro. Grande de propósito, porque o que você quer ver é ela
se dividindo.

```
[Escreva aqui uma tarefa real sua, de várias etapas. Por exemplo: "Levanta os cinco principais
concorrentes do meu serviço, confere o preço de cada um na página deles, e monta uma tabela
comparativa com preço, o que está incluído e o que não está."]
```

**O que olhar:** a tarefa se dividindo em cartões sem você pedir · cada cartão indo para um agente
diferente · um cartão esperando o outro terminar · o status mudando sozinho.

---

## As três coisas que costumam dar errado na primeira vez

**O sintoma: o coordenador começou a executar a tarefa ele mesmo.** É o erro mais comum. Ele é
capaz, então ele faz. Reforce no `SOUL.md` dele, e mande:

```
Você é o coordenador. Você não executa. Passe essa tarefa para o agente certo e me diga para quem
passou.
```

**O sintoma: todos os agentes estão usando o mesmo modelo caro.** Aconteceu porque o `config.yaml` de
alguém ficou com o valor padrão. Confere o do operador primeiro, que é o que mais roda.

**O sintoma: você pediu e nada aconteceu.** Regra da Aula 2: mexeu em perfil, o gateway precisa
reiniciar e a sessão precisa ser nova.

---

## Uma coisa antes de você começar a mexer

Este squad é um ponto de partida, e ele é genérico de propósito. Ele não conhece a sua empresa.

A primeira coisa que vale fazer, depois que ele estiver rodando, é abrir o `SOUL.md` de cada um e
escrever duas linhas sobre o seu contexto: o que você faz, e o que nesses agentes precisa mudar para
caber no seu trabalho.

Um squad genérico funcionando hoje vale mais do que um squad perfeito que você nunca montou. Mas um
squad que conhece o seu negócio é outra coisa.
